#include "matakuliah.h"
void createList(List_mk &L){
    first(L) = NULL;
}
void insertFirst(List_mk &L, adr_mk P){
    if(first(L) != NULL){
        next(P) = first(L);
        first(L) = P;
    }else{
        first(L) = P;
    }
}
void insertAfter(List_mk &L, adr_mk Prec, adr_mk P);
void insertLast(List_mk &L, adr_mk P);
void deleteFirst(List_mk &L, adr_mk &P);
void deleteLast(List_mk &L, adr_mk &P);
void deleteAfter(List_mk &L, adr_mk Prec, adr_mk &P);


/** PERLU MODIFIKASI */
adr_mk alokasimk(infotype_mk x){
    adr_mk P = new elmlist_mk;
    info(P) = x;
    next(P) = NULL;
    return P;
}
void dealokasi(adr_mk &P);
adr_mk findElm(List_mk L, infotype_mk x){
     adr_mk P = first(L);
    while(P != NULL) {
        if(info(P)==x) {
            return P;
        }
        P = next(P);
    }
    return NULL;
}
void printInfo(List_mk L){
    adr_mk P = first(L);
    cout << "List Mata Kuliah: " << endl;
    if(first(L) != NULL){
        while(P != NULL){
            cout << info(P) << ", ";
            P = next(P);
        }
    }else{
        cout << "KOSONG" << endl;
    }
    cout << endl;
}
