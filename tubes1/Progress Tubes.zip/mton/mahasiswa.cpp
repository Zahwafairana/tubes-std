#include "mahasiswa.h"
void createList(List_mhs &L){
    first(L) = NULL;
}
void insertFirst(List_mhs &L, adr_mhs P){
    if(first(L) != NULL){
        next(P) = first(L);
        first(L) = P;
    }else{
        first(L) = P;
    }
}
void insertAfter(List_mhs &L, adr_mhs Prec, adr_mhs P);
void insertLast(List_mhs &L, adr_mhs P);
void deleteFirst(List_mhs &L, adr_mhs &P);
void deleteLast(List_mhs &L, adr_mhs &P);
void deleteAfter(List_mhs &L, adr_mhs Prec, adr_mhs &P);


/** PERLU MODIFIKASI */
adr_mhs alokasi(infotype_mhs x){
    adr_mhs P = new elmlist_mhs;
    info(P) = x;
    next(P) = NULL;
    return P;
}
void dealokasi(adr_mhs &P);
adr_mhs findElm(List_mhs L, infotype_mhs x){
    adr_mhs P = first(L);
    do {
        if(info(P) == x) {
            return P;
        }
        P = next(P);
    } while(P != first(L));
    return NULL;
}
void printInfo(List_mhs L){
    adr_mhs P = first(L);
    cout << "List Mahasiswa: " << endl;
    if(first(L) != NULL){
        while(P != NULL){
            cout << info(P) << ", ";
            P = next(P);
        }
    }else{
        cout << "KOSONG" << endl;
    }
    cout << endl;
}
