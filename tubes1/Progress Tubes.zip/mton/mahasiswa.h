#ifndef MAHASISWA_H_INCLUDED
#define MAHASISWA_H_INCLUDED
#include <iostream>
using namespace std;

#define first(L) L.first
#define next(P) P->next
#define info(P) P->info
#define child(P) P->child

typedef string infotype_mhs;
typedef struct elmlist_mhs *adr_mhs;

struct elmlist_mhs {
    infotype_mhs info;
    //List_relasi child;
    adr_mhs next;
};

struct List_mhs {
    adr_mhs first;
};


/** TIDAK PERLU MODIFIKASI */
void createList(List_mhs &L);
void insertFirst(List_mhs &L, adr_mhs P);
void insertAfter(List_mhs &L, adr_mhs Prec, adr_mhs P);
void insertLast(List_mhs &L, adr_mhs P);
void deleteFirst(List_mhs &L, adr_mhs &P);
void deleteLast(List_mhs &L, adr_mhs &P);
void deleteAfter(List_mhs &L, adr_mhs Prec, adr_mhs &P);


/** PERLU MODIFIKASI */
adr_mhs alokasi(infotype_mhs x);
void dealokasi(adr_mhs &P);
adr_mhs findElm(List_mhs L, infotype_mhs x);
void printInfo(List_mhs L);

#endif // MAHASISWA_H_INCLUDED
