#ifndef MATAKULIAH_H_INCLUDED
#define MATAKULIAH_H_INCLUDED

#include <iostream>
using namespace std;

#define next(P) P->next
#define prev(P) P->prev
#define first(L) L.first
#define last(L) L.last
#define info(P) P->info

typedef string infotype_mk;
typedef struct elmlist_mk *adr_mk;

struct elmlist_mk{
    infotype_mk info;
    adr_mk next;
    adr_mk prev;
};

struct List_mk{
    adr_mk first;
    adr_mk last;
};

/** TIDAK PERLU MODIFIKASI */
void createList(List_mk &L);
void insertFirst(List_mk &L, adr_mk P);
void insertLast(List_mk &L, adr_mk P);
void insertAfter(List_mk &L, adr_mk Prec, adr_mk P);
void deleteFirst(List_mk &L, adr_mk &P);
void deleteLast(List_mk &L, adr_mk &P);
void deleteAfter(List_mk &L, adr_mk Prec, adr_mk &P);


/** PERLU MODIFIKASI */
adr_mk alokasimk(string x);
void dealokasi(adr_mk &P);
adr_mk findElm(List_mk L, string x);
void printInfo(List_mk L);
#endif // MATAKULIAH_H_INCLUDED
