#include "relasi.h"
void createList(List_r &L){
    first(L) = NULL;
}
adr_r alokasi(adr_mhs M, adr_mk MK){
    adr_r P = new elm_r;
    mahasiswa(P) = M;
    matakuliah(P) = MK;
    next(P) = NULL;
    prev(P) = NULL;
    return P;
}
void insertFirst(List_r &L, adr_r P){
    if(first(L) == NULL){
        first(L) = P;
        next(P) = P;
        prev(P) = P;
    }else{
        next(P) = first(L);
        prev(P) = prev(first(L));
        next(prev(P)) = P;
        first(L) = P;
    }
}
void deleteElement(List_r &L, adr_r &P){
    if(next(P) == P){
        first(L) = next(P);
    }else{
        if(first(L) == P){
            first(L) = next(P);
        }
        next(prev(P)) = next(P);
        prev(next(P)) = prev(P);
    }
    prev(P) = NULL;
    next(P) = NULL;
}

adr_r findElm(List_r L, adr_mhs M, adr_mk MK){
    adr_r P = first(L);
    if(P != NULL){
        do{
            if(mahasiswa(P) == M && matakuliah(P) == MK){
                return P;
            }
            P = next(P);
        }while(P != first(L));
    }
    return NULL;
}
adr_r findElm(List_r L, infotype_mhs M, string MK){
    adr_r P = first(L);
    if(P != NULL){
        do{
            if(info(mahasiswa(P)) == M && info(matakuliah(P)) == MK){
                return P;
            }
            P = next(P);
        }while(P != first(L));
    }
    return NULL;
}

void connect(List_r &L, List_mhs Lm, List_mk Lmk, infotype_mhs M, string MK){
    adr_mhs P = findElm(Lm, M);
    adr_mk Q = findElm(Lmk, MK);
    if(P != NULL && Q != NULL){
        adr_r R = alokasi(P,Q);
        insertFirst(L,R);
    }

}
void disconnect(List_r &L, infotype_mhs M, string MK){
    adr_r R = findElm(L,M,MK);
    if(R != NULL){
        deleteElement(L,R);
        delete R;
    }
}

void printRelasi(List_r L, List_mhs Lm){
    adr_mhs  P = first(Lm);
    cout << "Print Relasi" << endl;
    while(P != NULL){
        cout << info(P) << " - ";
        adr_r R = first(L);
        if(R != NULL){
            do{
                if(mahasiswa(R) == P){
                    cout << info(matakuliah(R)) << ", ";
                }
                R = next(R);
            }while(R != first(L));
        }
        cout << endl;
        P = next(P);
    }
    cout << endl;
}
