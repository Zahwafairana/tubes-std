#include <iostream>

using namespace std;
#include "mahasiswa.h"
#include "matakuliah.h"
#include "relasi.h"
int main()
{
    List_mhs Lm;
    List_mk Lmk;
    List_r Lr;
    adr_mhs P;
    adr_mk Q;
    adr_r R;

    createList(Lm);
    createList(Lmk);
    createList(Lr);

    P = alokasi("abi");
    insertFirst(Lm, P);
    P = alokasi("dika");
    insertFirst(Lm, P);
    P = alokasi("ray");
    insertFirst(Lm, P);

    Q = alokasimk("STD");
    insertFirst(Lmk,Q);
    Q = alokasimk("RPL");
    insertFirst(Lmk,Q);
    Q = alokasimk("COA");
    insertFirst(Lmk,Q);

    printInfo(Lm);
    cout << endl;
    printInfo(Lmk);

    connect(Lr,Lm,Lmk,"abi","STD");
    connect(Lr,Lm,Lmk,"abi","RPL");
    connect(Lr,Lm,Lmk,"ray","STD");
    connect(Lr,Lm,Lmk,"ray","COA");
    connect(Lr,Lm,Lmk,"dika","STD");
    connect(Lr,Lm,Lmk,"dika","RPL");
    connect(Lr,Lm,Lmk,"dika","COA");
    cout << endl;
    printRelasi(Lr,Lm);
    return 0;
}
